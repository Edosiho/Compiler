
#define NHASH 9997


#define BOOL_PRIM             0
#define INT_PRIM              1
#define DOUBLE_PRIM           2
#define STRING_PRIM           3
#define VOID_PRIM             4

#define START_ARR_PRIM        10

#define BOOL_ARR_PRIM         10
#define INT_ARR_PRIM          11
#define DOUBLE_ARR_PRIM       12

#define START_FUNC_PRIM       20


#define BOOL_FUNC_PRIM        20
#define INT_FUNC_PRIM         21
#define DOUBLE_FUNC_PRIM      22  
#define STRING_FUNC_PRIM      23
#define VOID_FUNC_PRIM        24

#define BOOL_ARR_FUNC_PRIM    30
#define INT_ARR_FUNC_PRIM     31
#define DOUBLE_ARR_FUNC_PRIM  32

#define INVALID          255




struct symtabList;
typedef struct args _args;
typedef struct symbol symbol;
typedef struct symbolList _symbolList;
typedef struct symtab _symtab;
typedef struct symtabList _symtabList;

struct args{
  _args* next;
	char type;
};

struct symbol{
    char type;	
    char *name;
    int counter;
    _args *args;
  };

  struct symbolList{
  	_symbolList* next;
  	symbol* symbol;
  };

  struct symtab{
  _symtab *parentNode;
	_symtabList *nodes;
	_symbolList *symbols[NHASH];  	
  };

  struct symtabList{
  	_symtab *value;
  	_symtabList *nextValue;
  };

  struct symbol* addr;
  int lineNumber;
  symbol* currFunction;
  _symtab* rootSymtab;
  _symtab* currSymtab;
  symbol* createSymbol(char* name);
  symbol* lookup(char* name);

  void pushSymbolTable();
  void popSymbolTable();
  char isTypeArr(char c);
  char isTypeFunc(char c);
  const char* conversion(char c);