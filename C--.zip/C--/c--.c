#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "c--.h"

static unsigned symhash(char *sym){
  unsigned int hash = 0;
  unsigned c;
  while(c = *sym++) hash = hash*9 ^ c;
  return hash;
}

symbol* lookup(char *name){
	_symtab* symtab = currSymtab;
	_symbolList* symbolList;
  printf("lookup\n" );
 	while (symtab != NULL){
 		symbolList = symtab->symbols[symhash(name) % NHASH];
  		if(symbolList != NULL){
  			while(symbolList->next != NULL){

  				if(strcmp(symbolList->symbol->name, name) == 0){
  					symbolList->symbol->counter++;
  					return symbolList->symbol;
  				}

  				symbolList = symbolList->next;
  			}
        if(strcmp(symbolList->symbol->name, name) == 0){
            symbolList->symbol->counter++;
            return symbolList->symbol;
        }

  		}
  		symtab = symtab->parentNode;
  	}
  	yyerror("Symbol doesn't exist");
      return NULL;
}

symbol* createSymbol(char *name){
	_symbolList* symbolList = currSymtab->symbols[symhash(name) % NHASH];

  printf("symbol created %s \n",name);

	if(symbolList != NULL){
  			while(symbolList->next != NULL){
  				symbolList = symbolList->next;
  		}
  	}
  	symbol* symbol = malloc(sizeof(symbol));
  	symbol->name =strdup(name);
  	symbol->counter = symbol->counter+1;
    printf("symbol:name %s\n",symbol->name );

  	_symbolList* nextList = malloc(sizeof(symbolList ));
  	nextList->next = NULL;
  	nextList->symbol = symbol;
  	if(symbolList != NULL){
  		symbolList-> next = nextList;
  	}
  	else{
  		currSymtab->symbols[symhash(name) % NHASH] = nextList;
  	}
  	return symbol;
}
void pushSymbolTable(){
  printf("pushed" );
  _symtab* symTab = malloc(sizeof(_symtabList ));
  symTab->parentNode = currSymtab;

  _symtabList* newList = malloc(sizeof(_symtabList ));
  newList->value = symTab;
  newList->nextValue = currSymtab->nodes;
  currSymtab->nodes = newList;
  currSymtab = symTab;
}
void popSymbolTable() {
    currSymtab = currSymtab->parentNode;
}

void createSymTable(){
  _symtab* symTab = malloc(sizeof(_symtab));
  symTab->parentNode =NULL;
  currSymtab =symTab;
  rootSymtab = symTab;

}


char areNums(char one,char two){
  printf("%d %d \n",one,two );
  return ((one == INT_PRIM || one == DOUBLE_PRIM) && one ==two);
}
char checkArgs (_args*  args1, _args* args2){
  while(args1 != NULL && args2 != NULL){
    if(args1 ->type != args2->type) return 1;

    args1 = args1->next;
    args2 = args2->next;
  }
  return (args1==NULL && args2 ==NULL);

}


