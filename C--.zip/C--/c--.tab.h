/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_C_TAB_H_INCLUDED
# define YY_YY_C_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    VOID = 258,
    INT = 259,
    DOUBLE = 260,
    BOOL = 261,
    STRING = 262,
    WHILE = 263,
    FOR = 264,
    IF = 265,
    RETURN = 266,
    PRINT = 267,
    SEMI = 268,
    COMMA = 269,
    LBRACKET = 270,
    RBRACKET = 271,
    LPAR = 272,
    RPAR = 273,
    LCURL = 274,
    RCURL = 275,
    READINT = 276,
    READLINE = 277,
    TRUE = 278,
    FALSE = 279,
    INTVAL = 280,
    DOUBLEVAL = 281,
    STRINGVAL = 282,
    IDENT = 283,
    OR = 284,
    AND = 285,
    SUM = 286,
    MIN = 287,
    MUL = 288,
    DIV = 289,
    MOD = 290,
    UMINUS = 291,
    EQUAL = 292,
    NOTEQUAL = 293,
    ASSIGN = 294,
    LESST = 295,
    LESSEQU = 296,
    MORET = 297,
    MOREEQU = 298,
    NOT = 299,
    THEN = 300,
    ELSE = 301
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 7 "c--.y" /* yacc.c:1909  */

 struct symbol* sym;
 struct  args* arg;
 char* n;
 char t;

#line 108 "c--.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_C_TAB_H_INCLUDED  */
